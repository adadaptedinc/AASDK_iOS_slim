//
//  AADetailedListItem.h
//  AASDK
//
//  Created by hollarab on 10/17/16.
//  Copyright © 2016 LameSauce Software. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AADetailedListItem : NSObject

@property (nonnull) NSString* payloadId;
@property (nonnull) NSString* trackingId;
@property (nonnull) NSString* productTitle;
@property (nullable) NSURL* productImageURL;
@property (nullable) NSString* productBrand;
@property (nullable) NSString* productCategory;
@property (nullable) NSString* productBarcode;
@property (nullable) NSNumber* productDiscount;

+(nullable instancetype)parseFromBase64String:(nullable NSString*)string;
+(nullable instancetype)parseFromDictionary:(nullable NSDictionary*)dictionary;

- (nullable NSString*)toBase64String;
- (nullable NSDictionary*)toDictionary;

@end
